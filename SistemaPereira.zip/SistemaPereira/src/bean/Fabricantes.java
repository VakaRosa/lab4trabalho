/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.sql.Date;

/**
 *
 * @author luzma
 */
public class Fabricantes {
    private int idFabricantes;
    private String nome;
    private String paisOrigem;
    private String siteOficial;
    private Date dataFundacao;

    /**
     * @return the idFabricantes
     */
    public int getIdFabricantes() {
        return idFabricantes;
    }

    /**
     * @param idFabricantes the idFabricantes to set
     */
    public void setIdFabricantes(int idFabricantes) {
        this.idFabricantes = idFabricantes;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the paisOrigem
     */
    public String getPaisOrigem() {
        return paisOrigem;
    }

    /**
     * @param paisOrigem the paisOrigem to set
     */
    public void setPaisOrigem(String paisOrigem) {
        this.paisOrigem = paisOrigem;
    }

    /**
     * @return the siteOficial
     */
    public String getSiteOficial() {
        return siteOficial;
    }

    /**
     * @param siteOficial the siteOficial to set
     */
    public void setSiteOficial(String siteOficial) {
        this.siteOficial = siteOficial;
    }

    /**
     * @return the dataFundacao
     */
    public Date getDataFundacao() {
        return dataFundacao;
    }

    /**
     * @param dataFundacao the dataFundacao to set
     */
    public void setDataFundacao(Date dataFundacao) {
        this.dataFundacao = dataFundacao;
    }
    
    
}
